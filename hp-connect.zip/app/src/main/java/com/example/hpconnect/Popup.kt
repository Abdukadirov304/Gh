package com.example.hpconnect

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView

object Popup {
    private var last = 0L

    fun show(ctx: Context, name: String, done: (() -> Unit)? = null) {
        val now = SystemClock.elapsedRealtime()
        if (now - last < 4000) {
            done?.invoke()
            return
        }
        last = now

        val app = ctx.applicationContext
        val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dp = app.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val card = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(20), px(14), px(26), px(14))
            background = GradientDrawable().apply {
                setColor(0xF21C1C1E.toInt())
                cornerRadius = px(34).toFloat()
            }
            elevation = px(8).toFloat()
        }

        val icon = TextView(app).apply {
            text = "🎧"
            textSize = 30f
        }

        val col = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(14), 0, 0, 0)
        }
        col.addView(TextView(app).apply {
            text = name
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, Typeface.BOLD)
        })
        col.addView(TextView(app).apply {
            text = "Подключено"
            textSize = 13f
            setTextColor(0xFF9A9AA0.toInt())
        })

        card.addView(icon)
        card.addView(col)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = px(48)
        }

        try {
            wm.addView(card, params)
        } catch (e: Exception) {
            done?.invoke()
            return
        }

        val offset = px(120).toFloat()
        card.alpha = 0f
        card.scaleX = 0.6f
        card.scaleY = 0.6f
        card.translationY = -offset
        card.animate()
            .alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(450)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()

        icon.animate()
            .scaleX(1.25f).scaleY(1.25f)
            .setStartDelay(450).setDuration(500)
            .withEndAction {
                icon.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(400).start()
            }
            .start()

        Handler(Looper.getMainLooper()).postDelayed({
            card.animate()
                .alpha(0f).scaleX(0.8f).scaleY(0.8f).translationY(-offset)
                .setDuration(350)
                .withEndAction {
                    try { wm.removeView(card) } catch (e: Exception) { }
                    done?.invoke()
                }
                .start()
        }, 3200)
    }
}
