package com.example.hpconnect

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
        }

        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }

        root.addView(TextView(this).apply {
            text = "Анимация подключения наушников\n\nСделай шаги 1 и 2 один раз, потом приложение можно закрыть."
            textSize = 16f
            setPadding(0, 0, 0, 32)
        })

        root.addView(btn("1. Разрешить Bluetooth") {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
            } else {
                Toast.makeText(this, "На твоей версии Android это не нужно", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(btn("2. Разрешить поверх других окон") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })

        root.addView(btn("3. Проверить анимацию") {
            if (Settings.canDrawOverlays(this)) {
                Popup.show(this, "AirPods Pro")
            } else {
                Toast.makeText(this, "Сначала сделай шаг 2", Toast.LENGTH_LONG).show()
            }
        })

        setContentView(root)
    }
}
