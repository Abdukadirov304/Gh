package com.example.hpconnect

import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

class BtReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED) return
        if (!Settings.canDrawOverlays(context)) return

        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }

        val major = try { device?.bluetoothClass?.majorDeviceClass } catch (e: SecurityException) { null }
        if (major != null && major != BluetoothClass.Device.Major.AUDIO_VIDEO) return

        val name = (try { device?.name } catch (e: SecurityException) { null }) ?: "Наушники"

        val pending = goAsync()
        Popup.show(context, name) { pending.finish() }
    }
}
